package ex2;

public class Exercise2 {
}
